
edge(s1,a).
edge(s1,b).
edge(a,c).
edge(b,d).
edge(c,g1).
edge(d,g2).
edge(d,f).
edge(f,g).

path(X,Y) :- edge(X,Y).
path(X,Y) :- edge(X,Z), path(Z,Y).
