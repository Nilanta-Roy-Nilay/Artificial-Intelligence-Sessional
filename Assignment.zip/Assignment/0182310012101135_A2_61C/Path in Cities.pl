edge(start,a).
edge(start,b).
edge(a,c).
edge(b,c).
edge(c,d).
edge(d,end).

path(X,Y) :- edge(X,Y).
path(X,Y) :- edge(X,Z), path(Z,Y).
