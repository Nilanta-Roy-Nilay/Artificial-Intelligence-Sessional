vegetarian(jose).
vegetarian(james).
vegetable(carrot).
vegetable(egg_plant).

loves(X, egg_plant) :-
    vegetarian(X).
