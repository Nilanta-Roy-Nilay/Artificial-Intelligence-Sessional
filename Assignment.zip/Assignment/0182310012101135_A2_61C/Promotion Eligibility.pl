employee(jason, 5, leadership).
employee(karen, 3, no_leadership).
employee(lucas, 6, no_leadership).
employee(maria, 4, leadership).

eligible(X) :-
    employee(X, Years, leadership),
    Years >= 5.

promotable(X) :-
    eligible(X).
