edge(s2, c).
edge(c, b).
edge(b, d).
edge(d, e).
edge(e, g2).

breadth_first(Start, Goal) :- 
    bfs([[Start]], Goal).

bfs([[Goal|Path]|_], Goal) :- 
    reverse([Goal|Path], Result), 
    write(Result).
bfs([Path|Paths], Goal) :- 
    extend(Path, NewPaths), 
    append(Paths, NewPaths, Paths1), 
    bfs(Paths1, Goal).

extend([Node|Path], NewPaths) :- 
    findall([NewNode,Node|Path], edge(Node, NewNode), NewPaths).
