friend(jin, james).
friend(jin, john).
likes(john, jin).
likes(james, john).
likes(jin, john).

happy(X) :-
    friend(X, Y),
    likes(X, Y),
    likes(Y, X).