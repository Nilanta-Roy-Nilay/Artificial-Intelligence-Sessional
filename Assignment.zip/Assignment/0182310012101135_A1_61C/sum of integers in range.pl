sumint(From, To, 0) :-
    From > To.
sumint(From, To, Sum) :-
    From =< To,
    Next is From + 1,
    sumint(Next, To, Rest),
    Sum is From + Rest.