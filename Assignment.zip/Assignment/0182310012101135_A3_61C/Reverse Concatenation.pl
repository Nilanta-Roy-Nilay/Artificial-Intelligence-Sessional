conc([], L, L).
conc([H|T], L, [H|R]) :- conc(T, L, R).

reverse_list([], []).
reverse_list([H|T], R) :- reverse_list(T, RT), append(RT, [H], R).

revers(L1, L2, L3) :- conc(L1, L2, L), reverse_list(L, L3).
