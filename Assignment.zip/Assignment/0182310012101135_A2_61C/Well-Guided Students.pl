mentors(mentor1, student1).
mentors(mentor1, student2).
respects(student1, mentor1).
respects(student2, mentor1).

well_guided(Student) :-
    mentors(Mentor, Student),
    respects(Student, Mentor).
