edge(s1, s2).
edge(s1, a).
edge(s2, b).
edge(a, c).
edge(b, d).
edge(c, g1).
edge(d, g2).
edge(e, f).

path(X, Y) :-
    edge(X, Y).
path(X, Y) :-
    edge(X, Z),
    path(Z, Y).