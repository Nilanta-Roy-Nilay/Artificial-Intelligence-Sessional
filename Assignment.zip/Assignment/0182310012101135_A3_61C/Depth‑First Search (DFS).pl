edge(s2, c).
edge(c, d).
edge(d, e).
edge(e, b).
edge(b, e).
edge(e, g1).
edge(g1, g2).

depth_first(Start, Goal) :- 
    dfs(Start, Goal, [Start], Path), 
    reverse(Path, Result), 
    write(Result).

dfs(Goal, Goal, Path, Path).
dfs(Node, Goal, Visited, Path) :- 
    edge(Node, Next), 
    \+ member(Next, Visited), 
    dfs(Next, Goal, [Next|Visited], Path).
