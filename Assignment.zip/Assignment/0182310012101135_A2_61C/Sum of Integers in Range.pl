sumint(I, J, Sum) :-
    I =< J,
    sum_helper(I, J, 0, Sum).

sum_helper(J, J, Acc, Sum) :-
    Sum is Acc + J.
sum_helper(I, J, Acc, Sum) :-
    I < J,
    NewAcc is Acc + I,
    Next is I + 1,
    sum_helper(Next, J, NewAcc, Sum).
