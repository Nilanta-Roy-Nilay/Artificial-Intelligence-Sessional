import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# --- 1. CONTROL SYSTEM SETUP (Loaded Once) ---

# Define input variables (Antecedents)
cloth_type = ctrl.Antecedent(np.arange(1, 4, 1), 'ClothType')
load_size = ctrl.Antecedent(np.arange(0, 11, 1), 'LoadSize')
dirtiness = ctrl.Antecedent(np.arange(0, 11, 1), 'Dirtiness')

# Define output variable (Consequent)
cycle_intensity = ctrl.Consequent(np.arange(0, 101, 1), 'CycleIntensity')

# Membership functions for Cloth Type
cloth_type['Delicate'] = fuzz.trimf(cloth_type.universe, [0.5, 1, 1.5])
cloth_type['Normal']   = fuzz.trimf(cloth_type.universe, [1.5, 2, 2.5])
cloth_type['Heavy']    = fuzz.trimf(cloth_type.universe, [2.5, 3, 3.5])

# Membership functions for Load Size
load_size['Small']  = fuzz.trimf(load_size.universe, [0, 2, 4])
load_size['Medium'] = fuzz.trimf(load_size.universe, [3, 5, 7])
load_size['Large']  = fuzz.trimf(load_size.universe, [6, 8, 10])

# Membership functions for Dirtiness
dirtiness['Low']    = fuzz.trimf(dirtiness.universe, [0, 2, 4])
dirtiness['Medium'] = fuzz.trimf(dirtiness.universe, [3, 5, 7])
dirtiness['High']   = fuzz.trimf(dirtiness.universe, [6, 8, 10])

# Membership functions for Cycle Intensity
cycle_intensity['Gentle'] = fuzz.trimf(cycle_intensity.universe, [0, 15, 30])
cycle_intensity['Normal'] = fuzz.trimf(cycle_intensity.universe, [30, 50, 70])
cycle_intensity['Intense'] = fuzz.trimf(cycle_intensity.universe, [70, 85, 100])

# Define rules
rule1 = ctrl.Rule(cloth_type['Heavy'] & load_size['Large'] & dirtiness['High'], cycle_intensity['Intense'])
rule2 = ctrl.Rule(cloth_type['Normal'] & load_size['Medium'] & dirtiness['Medium'], cycle_intensity['Normal'])
rule3 = ctrl.Rule(cloth_type['Delicate'] & load_size['Small'] & dirtiness['Low'], cycle_intensity['Gentle'])
rule4 = ctrl.Rule(cloth_type['Delicate'] & load_size['Medium'] & dirtiness['Medium'], cycle_intensity['Normal'])
rule5 = ctrl.Rule(cloth_type['Normal'] & load_size['Large'] & dirtiness['High'], cycle_intensity['Intense'])
rule6 = ctrl.Rule(cloth_type['Delicate'] & load_size['Small'] & dirtiness['Medium'], cycle_intensity['Gentle'])
rule7 = ctrl.Rule(cloth_type['Normal'] & load_size['Medium'] & dirtiness['High'], cycle_intensity['Normal'])
rule8 = ctrl.Rule(cloth_type['Delicate'] & load_size['Large'] & dirtiness['Low'], cycle_intensity['Gentle'])
rule9 = ctrl.Rule(cloth_type['Heavy'] & load_size['Medium'] & dirtiness['High'], cycle_intensity['Intense'])

# Build control system and simulation instance
washing_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9])
washing_sim = ctrl.ControlSystemSimulation(washing_ctrl)


# --- 2. DYNAMIC USER INPUT LOOP ---

print("==============================================")
print("     Washing Machine Fuzzy Control System     ")
print("==============================================")
print("Type 'exit' at any prompt to stop the program.\n")

while True:
    try:
        # Get Cloth Type input
        print("Select Cloth Type:")
        print("1 -> Delicate")
        print("2 -> Normal")
        print("3 -> Heavy")
        user_cloth = input("Your choice (1-3): ").strip()
        
        if user_cloth.lower() == 'exit':
            print("Shutting down the program. Thank you!")
            break
            
        # Convert to float
        c_type = float(user_cloth)
        
        # Check if within valid boundaries
        if c_type < 1 or c_type > 3:
            print("Invalid Input! Cloth Type must be between 1 and 3. Please try again.\n")
            continue

        # Get Load Size input
        user_load = input("Enter Load Size (From 0 to 10): ").strip()
        if user_load.lower() == 'exit': 
            print("Shutting down the program. Thank you!")
            break
        l_size = float(user_load)
        if l_size < 0 or l_size > 10:
            print("Invalid Input! Load Size must be between 0 and 10.\n")
            continue

        # Get Dirtiness input
        user_dirt = input("Enter Dirtiness Level (From 0 to 10): ").strip()
        if user_dirt.lower() == 'exit': 
            print("Shutting down the program. Thank you!")
            break
        dirt = float(user_dirt)
        if dirt < 0 or dirt > 10:
            print("Invalid Input! Dirtiness Level must be between 0 and 10.\n")
            continue

        # Pass inputs dynamically to the system
        washing_sim.input['ClothType'] = c_type
        washing_sim.input['LoadSize'] = l_size
        washing_sim.input['Dirtiness'] = dirt

        # Compute crisp output
        washing_sim.compute()
        
        # Format and display the result
        result = washing_sim.output['CycleIntensity']
        print("\n----------------------------------------------")
        print(f" Result (Cycle Intensity): {result:.2f}%")
        print("----------------------------------------------\n")

    except ValueError:
        print("\n Input Error: Please enter a valid number!\n")
    except Exception as e:
        print(f"\n An unexpected error occurred: {e}\n")