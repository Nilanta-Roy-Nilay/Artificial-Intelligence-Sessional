healthy(alex).
healthy(ben).
healthy(dan).

wealthy(ben).
wealthy(clara).

brave(dan).
brave(emma).

expedition(X) :-
    healthy(X),
    (wealthy(X); brave(X)).
